library(testthat)
library(cellrangerRkit)

test_check("cellrangerRkit")
