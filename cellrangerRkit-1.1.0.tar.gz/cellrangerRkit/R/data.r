#
# Copyright (c) 2016 10x Genomics, Inc. All rights reserved.
#

#' An example  GeneBarcodeMatrix object containing 7827 cells and 35635 genes.
#'
#' Data contains peripheral blood mononuclear cells (PBMCs) from human individual 1.
#' @return none. data documentation.
"gbm1"

#' An example  GeneBarcodeMatrix object containing 9515 cells and 35635 genes.
#'
#' Data contains peripheral blood mononuclear cells (PBMCs) from human individual 2.
#' @return none. data documentation.
"gbm2"
